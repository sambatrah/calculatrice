<template>
  <div class="container">
    <div class="calculator">
      <input type="text" v-model="expression" class="ecran" readonly>
      <div class="buttons">
        <button v-for="button in buttons" :key="button" @click="appendToExpression(button)" :class="{'button': true, 'orange-button': button === 'C'}">{{ button }}</button>
      </div>
      <div class="bottom-buttons">
        <button @click="calculate" class="button equal-button">=</button>
        <button @click="togglePower" class="button power-button">{{ isOn ? 'Off' : 'On' }}</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import * as math from 'mathjs';

const isOn = ref(false);
const expression = ref('');
const buttons = [
  '7', '8', '9', '/', 
  '4', '5', '6', '*', 
  '1', '2', '3', '-', 
  '0', '.', 'C', '+', 
  '(', ')', 'π', 'e', 
  '^', '√', 'sin', 'cos', 'tan', 'ln'
];

const togglePower = () => {
  isOn.value = !isOn.value;
  if (!isOn.value) {
    expression.value = '';
  }
};

const appendToExpression = (value) => {
  if (isOn.value) {
    if (value === 'C') {
      clear();
    } else if (value === 'π') {
      expression.value += 'pi';
    } else if (value === '√') {
      expression.value += 'sqrt(';
    } else if (value === 'ln') {
      expression.value += 'log(';
    } else if (['sin', 'cos', 'tan'].includes(value)) {
      expression.value += `${value}(`;
    } else {
      expression.value += value;
    }
  }
};

const clear = () => {
  expression.value = '';
};

const calculate = () => {
  if (isOn.value) {
    try {
      expression.value = math.evaluate(expression.value).toString();
    } catch (error) {
      expression.value = 'Error';
    }
  }
};
</script>

<style scoped>
html, body {
  height: 100%;
  margin: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #000;
}

.container {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
}

.calculator {
  width: 80%;
  max-width: 500px;
  margin: 20px;
  padding: 20px;
  border: 1px solid #444;
  border-radius: 25px;
  box-shadow: 0 15px 30px rgba(0, 0, 0, 0.6), 0 10px 10px rgba(0, 0, 0, 0.4);
  text-align: center;
  background: linear-gradient(145deg, #333333, #222222);
  color: #fff;
}

.ecran {
  width: 100%;
  padding: 15px;
  margin-bottom: 20px;
  font-size: 24px;
  border: 1px solid #666;
  border-radius: 15px;
  box-shadow: inset 0 6px 12px rgba(0, 0, 0, 0.2);
  background: #000;
  color: #fff;
}

.buttons {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
  width: 100%;
}

.bottom-buttons {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
}

.button {
  padding: 20px;
  font-size: 20px;
  cursor: pointer;
  border: none;
  border-radius: 15px;
  box-shadow: 0 8px #111, 0 12px 24px rgba(0, 0, 0, 0.4);
  background: linear-gradient(145deg, #444444, #333333);
  color: #fff;
  transition: all 0.2s ease-in-out;
}

.button:active {
  box-shadow: 0 4px #000, 0 6px 12px rgba(0, 0, 0, 0.4);
  transform: translateY(4px);
}

.equal-button {
  flex: 1;
  padding: 20px;
  font-size: 20px;
  cursor: pointer;
  border: none;
  border-radius: 15px;
  box-shadow: 0 8px #111, 0 12px 24px rgba(0, 0, 0, 0.4);
  background: linear-gradient(145deg, #4CAF50, #45a049);
  color: white;
  transition: all 0.2s ease-in-out;
  margin-right: 10px;
}

.equal-button:hover {
  background-color: #45a049;
}

.equal-button:active {
  box-shadow: 0 4px #000, 0 6px 12px rgba(0, 0, 0, 0.4);
  transform: translateY(4px);
}

.power-button {
  flex: 1;
  padding: 20px;
  font-size: 20px;
  cursor: pointer;
  border: none;
  border-radius: 15px;
  background: linear-gradient(145deg, #ff0000, #cc0000);
  color: white;
  box-shadow: 0 8px #111, 0 12px 24px rgba(0, 0, 0, 0.4);
  transition: all 0.2s ease-in-out;
}

.power-button:hover {
  background-color: #ff4d4d;
}

.power-button:active {
  box-shadow: 0 4px #000, 0 6px 12px rgba(0, 0, 0, 0.4);
  transform: translateY(4px);
}

.orange-button {
  background: linear-gradient(145deg, #FFA500, #FF8C00);
}

.orange-button:hover {
  background-color: #FF8C00;
}

.orange-button:active {
  box-shadow: 0 4px #000, 0 6px 12px rgba(0, 0, 0, 0.4);
  transform: translateY(4px);
}
</style>
